let complementos= document.getElementById('complementos');
let comun=document.querySelectorAll('.comun');
let eFiambre=document.querySelectorAll('.eFiambre');
let ePapas=document.querySelectorAll('.ePapas');
let agregadoPapas=document.querySelector('#agregadoPapas')
let agregadoHuevo=document.querySelector('#agregadoHuevo')
let agregadoQueso=document.querySelector('#agregadoQueso')
let agregadoJamon=document.querySelector('#agregadoJamon')
let papasCantidad=document.querySelector('.papasCantidad')
let huevoCantidad=document.querySelector('.huevoCantidad')
let agregar=document.querySelector(".agregar");
let pedido=document.querySelector(".pedido");
let tableOrder=document.querySelector(".tableOrder");
let rowOrder=document.querySelector(".rowOrder");
let detalleTicket=document.querySelector(".detalleTicket");
let hidden_precio,hidden_nombre,hidden_cant;
let elementos=document.querySelector(".elementos");
let importeOutput=document.querySelector(".importeOutput");
let enviar=document.querySelector(".enviar");
let carrito=document.querySelector(".carrito");
let cliente=document.querySelector(".cliente");
let checkbox=complementos.querySelectorAll("input");
let label=complementos.querySelectorAll(".lab");
let templa=document.querySelector(".templa")
let repetir = document.querySelector("#repetir")
detalleTicket.innerHTML=""
let pedidoActual={
	id:[],
	cantidad:parseInt(0),
	cliente:"",
	pedido: [],
	detalle:"",
	importe:parseInt()
};
let pedidoFinal={
	id:[],
	cantidad:parseInt(0),
	cliente:"",
	pedido: [],
	detalle:"",
	importe:parseInt()
};
let importeSuma=parseInt(0);
let j=0;
let pedidoImprimir=""

let celda=[],botonMas=[],botonMenos=[],botonId=[],celdaComida=[],celdaCantidad=[],celdaId=[],celdaPrecio=[],activ=[];
let pedi="";
let h=0;

for(var i=0;i<=50;i++){
	creaTd(celda,``,i,"celdatableOrder")
	tableOrder.appendChild(celda[i])
	creaBoton(botonMas,i,`+`,"celdaBoton")
	celda[i].appendChild(botonMas[i])
	creaBoton(botonMenos,i,`-`,"celdaBoton")
	celda[i].appendChild(botonMenos[i])
	creaTd(celdaId,i,0,"celdaId")
	celda[i].appendChild(celdaId[0])
	creaTd(celdaCantidad,1,0,"celdaCantidad")
	celda[i].appendChild(celdaCantidad[0])
	creaTd(celdaComida,"",0,"celdaComida")
	celda[i].appendChild(celdaComida[0])
	creaTd(celdaPrecio,"",0,"celdaPrecio")
	celda[i].appendChild(celdaPrecio[0])
	activ[i]=false
	$(celda).hide()
};
let ingredientes=[9];

let edit= localStorage.getItem("edit") || null
let session= localStorage.getItem("session") || null
		
$(document).ready(function(){

$(".agregadoPapas").hide()
$(".comidas").click(function(){$(".agregadoPapas").show()})
$(".agregadoHuevo").hide()
$(".comidas").click(function(){$(".agregadoHuevo").show()})
$(".agregadoQueso").hide()
$(".comidas").click(function(){$(".agregadoQueso").show()})
$(".agregadoJamon").hide()
$(".comidas").click(function(){$(".agregadoJamon").show()})
	
	$(".pedidoEdit").hide()
	if (edit!=null) {
		let edit2=JSON.parse(edit)
		let edit3=JSON.parse("["+edit2.detalle+"]")
		for(var i=0;i<edit3.length;i++){
		for(var h=0;h<=50;h++){
		if (activ[h]==false) {
			$(celda[h]).show()
			$(celda[h].children[2]).hide();
			celda[h].children[3].innerHTML=`${edit3[h].hidden_cant}`;
			celda[h].children[4].innerHTML=`${edit3[h].hidden_nombre}`;
			celda[h].children[5].innerHTML=`${edit3[h].hidden_precio}`;
			activ[h]=true
			break;
		}
	}
			pedidoActual.id[i]=i
			pedidoActual.pedido[i]=edit3[i];
		}
		cliente.value=JSON.parse(edit).cliente
		$(".navegador").hide();
		let cancel = document.createElement("button")
		cancel.setAttribute("class","cancelar")
		cancel.innerHTML="cancelar"
		let encabezado=document.querySelector(".Encabezado")
		encabezado.innerHTML=`<h2>Sobreescribiendo pedido...</h2> 
								<p><br>nro: ${JSON.parse(edit).id}<br>cliente: ${JSON.parse(edit).cliente}</p>`
		encabezado.appendChild(cancel)
		$(cancel).click(function(){
			localStorage.removeItem("edit")
			window.location.href="cuaderno.html"
		})
	}

	if(session==null){
	$(".general").hide()
	$(".navegador").hide()

	$(".form-date").submit(function(e){
		e.preventDefault()
		$(".form-date").hide()
		$(".general").show()
		$(".navegador").show()
		let fecha=document.querySelector(".fecha").value
		localStorage.setItem("session",fecha)
		$(".impDate").html(`<h2>${fecha}</h2>`)
	})

	}else {$(".form-date").hide();
	let fecha=localStorage.getItem("session")
			$(".impDate").html(`<h2>${fecha}</h2>`);
			}
})
$(".agregadoPapas").css("display","block")
$(".agregadoHuevo").css("display","block")
$(".agregadoQueso").css("display","block")
$(".agregadoJamon").css("display","block")

$(".elementos div").hide()

const mostrarElementos=(element)=>{
	$(`#${element}Href`).click(function(){
	$(".elementos div").hide()
	$(`#${element}`).show()
})
}
mostrarElementos("milanesas")
mostrarElementos("hamburguesas")
mostrarElementos("lomitos")
mostrarElementos("pizzas")
mostrarElementos("papas")
mostrarElementos("platos")
// mostrarElementos("empanadas")
$(`#empanadasHref`).click(function(){$(".elementos div").hide()})
mostrarElementos("bebidas")


let MilanesaComun= document.getElementById('MilanesaComun')
	.addEventListener("click",()=>{selectComida("comun","Milanesa comun",450)});

let MilanesaFiambre= document.getElementById('MilanesaFiambre')
	.addEventListener("click",()=>{selectComida("fiambre","Milanesa esp. de fiambre",520)});

let MilanesaPapas= document.getElementById('MilanesaPapas')
	.addEventListener("click",()=>{selectComida("papas","Milanesa esp. de papas",520)});

let JuniorComun= document.getElementById('JuniorComun')
	.addEventListener("click",()=>{selectComida("comun","Junior comun",270)});

let JuniorEspecial= document.getElementById('JuniorEspecial')
.addEventListener("click",()=>{selectComida("comun","Junior especial",300);
									label[5].style.display= "inline-block"
									checkbox[5].checked=true;});

let MegaComun= document.getElementById('MegaComun')
	.addEventListener("click",()=>{selectComida("comun","Mega comun",500)});

let MegaFiambre= document.getElementById('MegaFiambre')
	.addEventListener("click",()=>{selectComida("fiambre","Mega esp. de fiambre",600)});

let MegaPapas= document.getElementById('MegaPapas')
	.addEventListener("click",()=>{selectComida("papas","Mega esp. de papas",600)});

let LomitoComun= document.getElementById('LomitoComun')
	.addEventListener("click",()=>{selectComida("comun","Lomito comun",550)});

let LomitoFiambre= document.getElementById('LomitoFiambre')
	.addEventListener("click",()=>{selectComida("fiambre","Lomito esp. de fiambre",600)});

let LomitoPapas= document.getElementById('LomitoPapas')
	.addEventListener("click",()=>{selectComida("papas","Lomito esp. de papas",600)});

let PizzaComun= document.getElementById('PizzaComun')
	.addEventListener("click",()=>{selectComida(0,"Pizza comun",500)});

let PizzaJamon= document.getElementById('PizzaJamon')
	.addEventListener("click",()=>{selectComida(0,"Pizza esp. de jamon",600)});

let PizzaFugazza= document.getElementById('PizzaFugazza')
	.addEventListener("click",()=>{selectComida(0,"Pizza fugazza",550)});

let PizzaCalabresa= document.getElementById('PizzaCalabresa')
	.addEventListener("click",()=>{selectComida(0,"Pizza calabresa",650)});

let PizzaNapolitana= document.getElementById('PizzaNapolitana')
	.addEventListener("click",()=>{selectComida(0,"Pizza napolitana",600)});

let mediaPizzaComun= document.getElementById('mediaPizzaComun')
	.addEventListener("click",()=>{selectComida(0,"Pizza comun",250)});

let mediaPizzaJamon= document.getElementById('mediaPizzaJamon')
	.addEventListener("click",()=>{selectComida(0,"Media Pizza esp. de jamon",300)});

let mediaPizzaFugazza= document.getElementById('mediaPizzaFugazza')
	.addEventListener("click",()=>{selectComida(0,"Media Pizza fugazza",280)});

let mediaPizzaCalabresa= document.getElementById('mediaPizzaCalabresa')
	.addEventListener("click",()=>{selectComida(0,"Media Pizza calabresa",330)});

let mediaPizzaNapolitana= document.getElementById('mediaPizzaNapolitana')
	.addEventListener("click",()=>{selectComida(0,"Media Pizza napolitana",300)});


let PizzanesaP2= document.getElementById('PizzanesaP2')
	.addEventListener("click",()=>{selectComida(0,"Pizzanesa p/2",1000)});

let PizzanesaP4= document.getElementById('PizzanesaP4')
	.addEventListener("click",()=>{selectComida(0,"Pizzanesa p/4",1800)});

let PapasComun= document.getElementById('PapasComun')
	.addEventListener("click",()=>{selectComida(0,"Papas comun",250)});

let PapasGratinadas= document.getElementById('PapasGratinadas')
	.addEventListener("click",()=>{selectComida(0,"Papas gratinadas",350)});

let Salchipapas= document.getElementById('Salchipapas')
	.addEventListener("click",()=>{selectComida(0,"Salchipapas",400)});

let MilanesaNapolitana= document.getElementById('MilanesaNapolitana')
	.addEventListener("click",()=>{selectComida(0,"Napolitana",500)});

let MilanesaCaballo= document.getElementById('MilanesaCaballo')
	.addEventListener("click",()=>{selectComida(0,"Mila a caballo",500)});

let MexicanoP1= document.getElementById('MexicanoP1')
	.addEventListener("click",()=>{selectComida(0,"Mexicano p/1",500)});

let MexicanoP2= document.getElementById('MexicanoP2')
	.addEventListener("click",()=>{selectComida(0,"Mexicano p/2",900)});

let EmpanadasCarne= document.getElementById('EmpanadasCarne')
	.addEventListener("click",()=>{selectComida(0,"Empanada de carne",600)});

let EmpanadasPollo= document.getElementById('EmpanadasPollo')
	.addEventListener("click",()=>{selectComida(0,"Empanada de pollo",600)});

let Pepsi2L= document.getElementById('Pepsi2L')
	.addEventListener("click",()=>{selectComida(0,"Pepsi 2L",250)});

let Pepsi1_14= document.getElementById('Pepsi1-1/4')
	.addEventListener("click",()=>{selectComida(0,"Pepsi 1.25L",180)});

let VasoGaseosa= document.getElementById('VasoGaseosa')
	.addEventListener("click",()=>{selectComida(0,"Vaso(pepsi)",50)});

let JugoFresh= document.getElementById('JugoFresh')
	.addEventListener("click",()=>{selectComida(0,"Jugo fresh",120)});

let LataQuilmes= document.getElementById('LataQuilmes')
	.addEventListener("click",()=>{selectComida(0,"Lata quilmes",300)});






$(agregadoPapas).click(function(){
	if (agregadoPapas.checked== true)
	papasCantidad.disabled=false
else  {papasCantidad.disabled=true
	papasCantidad.value=1;
}})
$(agregadoHuevo).click(function(){
	if (agregadoHuevo.checked== true)
	huevoCantidad.disabled=false
else  {huevoCantidad.disabled=true
		huevoCantidad.value=1;
}})


agregar.addEventListener("click",()=>{
	$(".elementos div").hide()
	if(hidden_nombre!=undefined){
	pedidoActual.cantidad+=1
	if (agregadoPapas.checked== true){hidden_nombre+=`(+ ${papasCantidad.value} AGREGADO de PAPAS)`
	hidden_precio+=(50*papasCantidad.value);}
	if (agregadoHuevo.checked== true){hidden_nombre+=`(+ ${huevoCantidad.value} AGREGADO de HUEVO)`
	hidden_precio+=(50*huevoCantidad.value);}
	if (agregadoQueso.checked== true){hidden_nombre+=`(+ AGREGADO de QUESO)`
	hidden_precio+=(50);}
	if (agregadoJamon.checked== true){hidden_nombre+=`(+ AGREGADO de JAMON)`
	hidden_precio+=(50);}
	
	let aux=true;

		if (checkboxs==true) {
			for (var i = 0; i < 8; i++) {
					if (checkbox[i].checked==false) {
						if (label[i].style.display=="inline-block"){
							switch(aux){
								case true:
								pedi= ` (sin `+`${checkbox[i].id})`
								;aux=false;break;
								case false:
								pedi+= `, (sin `+`${checkbox[i].id})`
								break;
							}								
						}
				
				}
			}
				if (aux==true) {
				
				pedi=` (completa) `
				}
		}
	j++;
	
}
if (hidden_nombre!=undefined) {
	hidden_nombre+=pedi
	// Aki me qede 31 de julio 17:47  poner hiddennombre=hidnombre+pedi pa q funcione lo de editar pedido
	// ***********************************************************************
	for(var h=0;h<=50;h++){
		if (activ[h]==false) {
			$(celda[h]).show()
			$(celda[h].children[2]).hide();
			celda[h].children[4].innerHTML=`${hidden_nombre}`;
			celda[h].children[3].innerHTML=`${hidden_cant}`;
			celda[h].children[5].innerHTML=`${hidden_precio}`;
			activ[h]=true
			break;
		}
	}
	
let g=0,repet=true;

	do{
		if (pedidoActual.id[g]==undefined) {
			pedidoActual.id[g]=g
			pedidoActual.pedido[g]={hidden_nombre,hidden_precio,hidden_cant};
			repet=false;
		}
		else g++;
	}while(repet==true);
}
	if (hidden_nombre!=undefined) {
	sumadorDeImportes();
	importeOutput.value=pedidoFinal.importe
	}
hidden_nombre= undefined


})



		celda.forEach(cel=>{
			cel.children[0].addEventListener("click",()=>{
				pedidoActual.id.forEach(id=>{
				console.log("ee")
					if(cel.children[2].textContent==id){
						pedidoActual.pedido[id].hidden_cant++;
						pedidoActual.pedido[id].hidden_precio=pedidoActual.pedido[id].hidden_precio/(pedidoActual.pedido[id].hidden_cant-1)*pedidoActual.pedido[id].hidden_cant;
						cel.children[3].innerHTML=`${pedidoActual.pedido[id].hidden_cant}`;
						cel.children[5].innerHTML=`${pedidoActual.pedido[id].hidden_precio}`;
					}
				})
			sumadorDeImportes();
			importeOutput.value=pedidoFinal.importe
			})
			cel.children[1].addEventListener("click",()=>{
				pedidoActual.id.forEach(id=>{
					if(cel.children[2].textContent==id){
						// console.log(pedidoActual.pedido[id])
						pedidoActual.pedido[id].hidden_cant--;
						if (pedidoActual.pedido[id].hidden_cant==0){
							pedidoActual.id[id]=undefined
							pedidoActual.pedido[id]="";
							cel.children[4].innerHTML=``;
							cel.children[3].innerHTML=1;
							cel.children[5].innerHTML=``;
							$(cel).hide()
							activ[id]=false
						}
						else{
							pedidoActual.pedido[id].hidden_precio=pedidoActual.pedido[id].hidden_precio-(pedidoActual.pedido[id].hidden_precio/(pedidoActual.pedido[id].hidden_cant+1));
							cel.children[3].innerHTML=`${pedidoActual.pedido[id].hidden_cant}`;
							cel.children[5].innerHTML=`${pedidoActual.pedido[id].hidden_precio}`;
						}
					}
				})
				sumadorDeImportes();
				importeOutput.value=pedidoFinal.importe
			})
		})

		const sumadorDeImportes=()=>{
		let sumaImportes=0;
		celda.forEach(cel=>{
			pedidoActual.id.forEach(id=>{
				if(cel.children[2].textContent==id){
					sumaImportes+=parseInt(cel.children[5].textContent) // AKI MeKEDEE
				}
			})
		})
		pedidoFinal.importe=sumaImportes;
		}
		const sumadorDeCant=()=>{
		let sumaCant=0;
		celda.forEach(cel=>{
			pedidoActual.id.forEach(id=>{
				if(cel.children[2].textContent==id){
					sumaCant+=parseInt(cel.children[3].textContent) // AKI MeKEDEE
				}
			})
		})	
		pedidoFinal.cantidad=sumaCant
		}
		const actualAFinal_pedido=()=>{
		let i=0;
		celda.forEach(cel=>{
			pedidoActual.id.forEach(id=>{
				if(cel.children[2].textContent==id){
					pedidoFinal.pedido[i]=pedidoActual.pedido[id]
					i++;
				}
			})
		})	
		}
		const actualAFinal_detalle=()=>{
		celda.forEach(cel=>{
			pedidoActual.id.forEach(id=>{
				if(cel.children[2].textContent==id){
					pedidoFinal.detalle+=`${cel.children[3].textContent} ${cel.children[4].textContent}<br><br>`
				}
			})
		})	
		}

let milanesas= document.getElementById('milanesasHref');
let hamburguesas= document.getElementById('hamburguesasHref');
let lomitos= document.getElementById('lomitosHref');
let pizzas= document.getElementById('pizzasHref');
let papas= document.getElementById('papasHref');
let platos= document.getElementById('platosHref');
let empanadas= document.getElementById('empanadasHref');
let bebidas= document.getElementById('bebidasHref');
let checkboxs= false;

	
	
	[milanesas,lomitos,hamburguesas].forEach(item=>{
		item.addEventListener("click",()=>{checkboxs=true})});
	[pizzas, papas,platos,bebidas].forEach(item => {
		item.addEventListener("click",()=>{noneLabel(label);checkboxs=false})});




carrito.addEventListener("submit",(e)=>{
e.preventDefault();
			try{
				actualAFinal_pedido()
	if (pedidoFinal.pedido.length!=0) {
				sumadorDeImportes();
				sumadorDeCant();
				
				actualAFinal_detalle()
				console.log(cliente.value)
				pedidoFinal.cliente=cliente.value;
				
			if (edit!=null) {
				fetch(`http://localhost:3000/pedidos/${JSON.parse(edit).id}`,{
					method: "PUT",
					body: JSON.stringify(pedidoFinal),
					headers: {"content-type": "application/json"}
				})	
				ticketCosina(JSON.parse(edit).id,pedidoFinal.cliente,pedidoFinal.detalle)
				localStorage.removeItem("edit")
				window.location.href="cuaderno.html"

			}
				else{
				 enviarData();
				
				 fetch("http://localhost:3000/pedidos")
				 .then(r=>r.json())
				 .then(resultado=>{
				 	console.log(resultado)
				 	console.log(resultado[resultado.length-1].id)
				 	console.log(resultado[resultado.length-1].id)
					ticketCosina(resultado[resultado.length-1].id,pedidoFinal.cliente,pedidoFinal.detalle)
					window.location.reload();

				 }
				 	)
					
			}
				
				
			}
	else {alert("no se ingreso ningun pedido")
		window.location.reload();
}
	$(".enviar").click(function(){$(".enviar").hide()})
			}
			catch(err){
				alert("a ocurrido un error")
				console.log(err)
			}	
})


const enviarData=()=>{
fetch("http://localhost:3000/pedidos",{
		method: "POST",
		body: JSON.stringify(pedidoFinal),
		headers: {"content-type": "application/json"}
	})
}

