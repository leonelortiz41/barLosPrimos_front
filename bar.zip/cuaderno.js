let data,output=[],delivery1="Maia",delivery2="Barbi",retiro="retirado",pagado="pagado";
let hidden_delivery1=[],hidden_delivery2=[];
let agregar=document.querySelector(".agregar")
let table1=document.querySelector(".table1")
let table2=document.querySelector(".table2")
let table3=document.querySelector(".table3")
let tableDelivery1=document.querySelector(".delivery1")
let tableDelivery2=document.querySelector(".delivery2")
let repartoDelivery1=document.querySelector(".repartoDeliv1")
let repartoDelivery2=document.querySelector(".repartoDeliv2")
let repartoCliente1=document.querySelector(".repartoClients1")
let repartoCliente2=document.querySelector(".repartoClients2")
let importe1=document.querySelector(".importe1")
let importe2=document.querySelector(".importe2")
let nombreTikDelivery=document.querySelector(".nombreTikDelivery")
let tbodyTikDelivery=document.querySelector(".tbodyTikDelivery")
let noTempla=document.querySelector(".noTempla")
let suma=parseInt(0),viajes1=parseInt(0),viajes2=parseInt(0);
let hd2=0,hd1=0,ejecucion1=false,ejecucion2=false;
let fila=[],filaTik=[];
let celda=[];
let botonEnv=[],botonDeli=[];


const fecha=localStorage.getItem("session")
$(".impDate").html(`<h2>${fecha}</h2>`)

nombreTikDelivery.textContent=""
tableDelivery1.textContent=delivery1
tableDelivery2.textContent=delivery2
repartoDelivery1.textContent=delivery1
repartoDelivery2.textContent=delivery2
repartoCliente1.innerHTML=``
repartoCliente2.innerHTML=``
importe1.innerHTML=`cantidad: ${viajes1}<br>$${viajes1*17}`
importe2.innerHTML=`cantidad: ${viajes2}<br>$${viajes2*17}`

const recibirData=async (data)=>{
	data=""
 data= await fetch("http://localhost:3000/pedidos")
 let r= await data.json()

let dadaa=[],comida=[]
			// console.log(dadaa.pedidos[0].hidden_nombre)
for(var j=0;j < r.length;j++){
			dadaa[j]=JSON.parse(`{ "pedidos": [${r[j].detalle}]}`)

				for(var i=0;i<=dadaa[j].pedidos.length-1;i++){
				if(comida[j]==undefined)comida[j]=`${dadaa[j].pedidos[i].hidden_cant} ${dadaa[j].pedidos[i].hidden_nombre}`;
				else comida[j]+=`<br>`+`${dadaa[j].pedidos[i].hidden_cant} ${dadaa[j].pedidos[i].hidden_nombre}`;
					
				}
			creaTr(fila,j)
			table1.appendChild(fila[j]);
			creaTd(celda,r[j].id,0,"celda");
			creaTd(celda, comida[j] ,1,"celDetalles");
			creaTd(celda,r[j].cliente,2,"celda");
			creaTd(celda,`$${r[j].importe}`,3,"celda");
			creaTd(celda,r[j].cantidad,4,"celda");
			creaTd(celda,"",5)
			creaTd(celda,r[j].detalleTicket,6,"none");
			creaTd(celda,r[j].id,7,"none");
			
				for(var i=0;i < celda.length;i++){
				fila[j].appendChild(celda[i])
				}
			let div=document.createElement("DIV")
			fila[j].children[5].appendChild(div)
			creaBoton(botonDeli,10,delivery1,"boton");
			creaBoton(botonDeli,11,delivery2,"boton");
			creaBoton(botonDeli,12,"retirar","boton");
			creaBoton(botonDeli,14,"pagar","boton");
			creaBoton(botonDeli,3,`<i class="fa-solid fa-print"></i>`,"imp");
			creaBoton(botonDeli,6,`<i class="fa-solid fa-trash-can"></i>`,"borr");
			creaBoton(botonDeli,13,`<i class="fa-solid fa-chevron-right"></i>`,"mas");
			creaBoton(botonDeli,15,`<i class="fa-solid fa-pen-to-square"></i>`,"boton");
			creaBoton(botonDeli,16,`<i class="fa-solid fa-receipt"></i>`,"boton");
			creaBoton(botonDeli,17,`PJ`,"boton");
			$(fila[j].children[5]).addClass("colBotones");
			$(fila[j].children[5].children[0]).addClass("divBotones");
			fila[j].children[5].children[0].appendChild(botonDeli[13])
			fila[j].children[5].children[0].appendChild(botonDeli[10])
			fila[j].children[5].children[0].appendChild(botonDeli[11])
			fila[j].children[5].children[0].appendChild(botonDeli[12])
			fila[j].children[5].children[0].appendChild(botonDeli[14])
			fila[j].children[5].children[0].appendChild(botonDeli[3])
			fila[j].children[5].children[0].appendChild(botonDeli[6])
			fila[j].children[5].children[0].appendChild(botonDeli[15])
			fila[j].children[5].children[0].appendChild(botonDeli[16])
			fila[j].children[5].children[0].appendChild(botonDeli[17])
			suma +=r[j].importe;

}

$(".imp").addClass("boton");
$(".borr").addClass("boton");
$(".boton").css("display","none");

	let	celdaTotal=document.createElement("td")
	celdaTotal.setAttribute("class","celdaTotal")
	celdaTotal.innerHTML=`Importe total :   $${suma}`
	table1.appendChild(celdaTotal)

let aregloLS=JSON.parse(localStorage.getItem("pedidosEnViaje")) || []
let aregloViajeLS=JSON.parse(localStorage.getItem("pedidosViaje")) || []
let pagaJusto=JSON.parse(localStorage.getItem("pagaJusto")) || []

pagaJusto.forEach(PaJu=>{
	fila.forEach(item=>{
		if(PaJu.id== item.children[0].textContent){
			item.children[3].innerHTML+=` <b>(PJ)</b>`
			$(item.children[3]).css("color","#16ea31")
		}
	})
})

aregloLS.forEach(aregloLS=>{
if(aregloLS.delivery== delivery1){
		fila.forEach(item=>{
			if(aregloLS.id==item.children[7].textContent) {
				item.children[5].innerHTML=`${delivery1}`
			item.children[5].style="box-shadow: inset 8px -1px 10px -6px #fff;"
			item.children[5].style.background=" linear-gradient(to right, #226425, #010101)";
		}
		})
		viajes1+=parseInt(aregloLS.cantidad);
		importe1.innerHTML=`cantidad: ${viajes1}<br>$${viajes1*17}`
}
if(aregloLS.delivery== delivery2){
	fila.forEach(item=>{
			if(aregloLS.id==item.children[7].textContent) {
				item.children[5].innerHTML=`${delivery2}`
			item.children[5].style="box-shadow: inset 8px -1px 10px -6px #fff;"
			item.children[5].style.background=" linear-gradient(to right, #226425, #010101)";
		}
		})
		viajes2+=parseInt(aregloLS.cantidad);
		importe2.innerHTML=`cantidad: ${viajes2}<br>$${viajes2*17}`
}
if(aregloLS.delivery== pagado){
	fila.forEach(item=>{
			if(aregloLS.id==item.children[7].textContent) {
			item.children[5].style="box-shadow: inset 8px -1px 10px -6px #fff;"
			item.children[5].style.background=" linear-gradient(to right, #bea719, #010101)";
			creaOutput(output,1,pagado)
			item.children[5].appendChild(output[1])
			$(".output").css("float","left")
			// $(item.children[5].children[0]).css("width","290px")
			$(item.children[5].children[0]).css("float","right")
			for(var i=1;i<=3;i++){
				$(item.children[5].children[0].children[i]).show()
				$(item.children[5].children[0].children[i]).css("background","#000")
				$(item.children[5].children[0].children[i]).css("color","#bea719")
				}
			$(item.children[5].children[0].children[0]).hide()
		}
		})
}
if(aregloLS.delivery== retiro){
	fila.forEach(item=>{
			if(aregloLS.id==item.children[7].textContent) {
				item.children[5].innerHTML=`${retiro}`
			item.children[5].style="box-shadow: inset 8px -1px 10px -6px #fff;"
			item.children[5].style.background=" linear-gradient(to right, #226425, #010101)";
		}
		})
}
})


aregloViajeLS.forEach(aregloViajeLS=>{
if(aregloViajeLS.delivery== delivery1){
		fila.forEach(item=>{
			if(aregloViajeLS.id==item.children[7].textContent) {
				for (var i = item.children[5].children[0].children.length-1; i>=0; i--) {
			item.children[5].children[0].removeChild(item.children[5].children[0].children[i])
			}
			if (item.children[5].children[1]) {	
			item.children[5].removeChild(item.children[5].children[1])
			item.children[5].innerHTML=`${delivery1}(pagado)`		
			}
			else{
			item.children[5].innerHTML=`${delivery1}`
			}
			item.children[5].style="box-shadow: inset 8px -1px 10px -6px #fff;"
			item.children[5].style.background=" linear-gradient(to right, #816907, #010101)";
		repartoCliente1.innerHTML+=`${aregloViajeLS.cliente}<br>`;
		ejecucion1=true
			printPrint(ejecucion1,0,4,hidden_delivery1,aregloLS);
			borraDelivery(ejecucion1,0,7,delivery1);
		hidden_delivery1[hd1]=	item;
		hd1++;	
		}
		})
}
if(aregloViajeLS.delivery== delivery2){
		fila.forEach(item=>{
			if(aregloViajeLS.id==item.children[7].textContent) {
				for (var i = item.children[5].children[0].children.length-1; i>=0; i--) {
			item.children[5].children[0].removeChild(item.children[5].children[0].children[i])
			}
			console.log(item.children[5].children[1])
			if (item.children[5].children[1]){				
			item.children[5].removeChild(item.children[5].children[1])
			item.children[5].innerHTML=`${delivery2}(pagado)`
			}
			else{
			item.children[5].innerHTML=`${delivery2}`
			}
			item.children[5].style="box-shadow: inset 8px -1px 10px -6px #fff;"
			item.children[5].style.background=" linear-gradient(to right, #816907, #010101)";
		repartoCliente2.innerHTML+=`${aregloViajeLS.cliente}<br>`;
		ejecucion2=true
			printPrint(ejecucion2,1,5,hidden_delivery2,aregloLS);
			borraDelivery(ejecucion2,1,8,delivery2);
		hidden_delivery2[hd2]=	item;
		hd2++;	
		}
		})
}
})


fila.forEach(item=>{
	if (item.children[5].innerHTML!= delivery1 && item.children[5].innerHTML!= `${delivery1}(pagado)`) {
		if (item.children[5].innerHTML!= delivery2 && item.children[5].innerHTML!= `${delivery2}(pagado)`) {
			if (item.children[5].innerHTML!= retiro){
				if (item.children[5].innerHTML!= pagado){
		item.children[5].children[0].children[1].addEventListener("click",()=>{	
			if (ejecucion1==false) {
			hidden_delivery1[hd1]=	item;
			hd1++;		
			item.children[5].style="box-shadow: inset 8px -1px 10px -6px #fff;"
			for (var i = item.children[5].children[0].children.length-1; i>=0; i--) {
			item.children[5].children[0].removeChild(item.children[5].children[0].children[i])
			}
			creaOutput(output,0,delivery1)
			item.children[5].appendChild(output[0])
			}
		})		
		item.children[5].children[0].children[2].addEventListener("click",()=>{	
			if (ejecucion2==false || item.children[5].classList=="en_viaje") {
			hidden_delivery2[hd2]=	item;
			hd2++;	
			item.children[5].style="box-shadow: inset 8px -1px 10px -6px #fff;"
			for (var i = item.children[5].children[0].children.length-1; i>=0; i--) {
			item.children[5].children[0].removeChild(item.children[5].children[0].children[i])
			}
			creaOutput(output,1,delivery2)
			item.children[5].appendChild(output[1])			
			}
		})
		item.children[5].children[0].children[4].addEventListener("click",()=>{	
			r.forEach(r=>{
				if(r.id==item.children[7].textContent){
					setEnViajeLS(r,pagado)
				};		
			})
			item.children[5].style="box-shadow: inset 8px -1px 10px -6px #fff;"
			item.children[5].style.background=" linear-gradient(to right, #bea719, #010101)";

			
			for (var i = item.children[5].children[0].children.length-1; i>=0; i--) {
				$(item.children[5].children[0].children[i]).hide()
			}
				for(var i=1;i<=3;i++){
				$(item.children[5].children[0].children[i]).show()
				$(item.children[5].children[0].children[i]).css("background","#000")
				$(item.children[5].children[0].children[i]).css("color","#bea719")
				}
			creaOutput(output,1,pagado)
			item.children[5].appendChild(output[1])					
			$(".output").css("float","left")
			// $(item.children[5].children[0]).css("width","290px")
			$(item.children[5].children[0]).css("float","right")
		})
		item.children[5].children[0].children[3].addEventListener("click",()=>{	
				
		
			let aregloLS2=JSON.parse(localStorage.getItem("pedidosEnViaje"))
			aregloLS2.forEach(arr=>{
				if(item.children[7].textContent==arr.id){
					arr.delivery=retiro
				
				}
			})	
					let arrEnviajeJSON=JSON.stringify(aregloLS2);
					localStorage.setItem("pedidosEnViaje",arrEnviajeJSON)

			item.children[5].style="box-shadow: inset 8px -1px 10px -6px #fff;"
			item.children[5].style.background=" linear-gradient(to right, #226425, #010101)";
			for (var i = item.children[5].children[0].children.length-1; i>=0; i--) {
			item.children[5].children[0].removeChild(item.children[5].children[0].children[i])
			}
			item.children[5].removeChild(output[1])
			creaOutput(output,1,retiro)
			item.children[5].appendChild(output[1])					
		})


// desplegar mas
		item.children[5].children[0].children[0].addEventListener("click",()=>{	
			if(item.children[5].children[0].children[2].style.display=="none"){	
			item.children[5].children[0].children[0].innerHTML=`<i class="fa-solid fa-chevron-left"></i>`
				for(i=item.children[5].children[0].children.length-1;i>=0;i--){
					$(item.children[5].children[0].children[i]).css("display","inline")
				}
				$(item.children[5].children[0].children[3]).hide()
			}
			else{
			item.children[5].children[0].children[0].innerHTML=`<i class="fa-solid fa-chevron-right"></i>`
				for(i=item.children[5].children[0].children.length-1;i>=0;i--){	
						$(item.children[5].children[0].children[i]).hide()
				}
				$(item.children[5].children[0].children[0]).show()
				
			}

			
		})

	// boton de imprimir
		item.children[5].children[0].children[5].addEventListener("click",()=>{	
			for(var i=0;i<=r.length-1;i++){
				if(item.children[0].textContent==r[i].id){
			ticketCosina(item.children[0].textContent,item.children[2].textContent,r[i].detalleTicket)
				}
			}
		});

	// boton de borrar
		item.children[5].children[0].children[6].addEventListener("click",()=>{				
			fetch(`http://localhost:3000/pedidos/${item.children[7].textContent}`,{
		method: "DELETE"
	})
			window.location.reload();
		});
// editor de pedidos
		item.children[5].children[0].children[7].addEventListener("click",()=>{							
			for(var i=0;i<=r.length-1;i++){
				if(item.children[0].textContent==r[i].id){
			localStorage.setItem("edit",JSON.stringify(r[i]))
				}
			}
			editPedido();
		});
// imprime recibo
		item.children[5].children[0].children[8].addEventListener("click",()=>{				
			
			for(var i=0;i<=fila.length-1;i++){
				if(fila[i].children[0].textContent==item.children[0].textContent){
				ticketCliente(dadaa[i],item.children[3].textContent)
				}
			}
		});
		item.children[5].children[0].children[9].addEventListener("click",()=>{				
			item.children[3].innerHTML+=` <b>(PJ)</b>`
			$(item.children[3]).css("color","#16ea31")
			r.forEach(r=>{
				if(r.id== item.children[0].textContent){
					pagaJusto.push(r)
					let pagaJustoJSON= JSON.stringify(pagaJusto)
					localStorage.setItem("pagaJusto",pagaJustoJSON)
				}
			})
			// item.children[3].style="color: #25e369;"
		});

	}}}}
});
	
agregar.addEventListener("click",()=>{

	agregarViaje(fila,hidden_delivery1,ejecucion1,repartoCliente1,delivery1,0,4,7,r)
	if (ejecucion1==false && hidden_delivery1.length>0) ejecucion1=true;

	agregarViaje(fila,hidden_delivery2,ejecucion2,repartoCliente2,delivery2,1,5,7,r)
	if (ejecucion2==false && hidden_delivery2.length>0) ejecucion2=true;
})

let ok1=document.querySelector(".ok1").addEventListener("click",()=>{
	viajes1=parseInt(darOk(ejecucion1,delivery1,hidden_delivery1,viajes1,repartoCliente1,hd1,importe1,0,4,r))
	ejecucion1=false;hd1=0;
});

let ok2=document.querySelector(".ok2").addEventListener("click",()=>{
	viajes2=parseInt(darOk(ejecucion2,delivery2,hidden_delivery2,viajes2,repartoCliente2,hd2,importe2,1,5,r))
	ejecucion2=false;hd2=0;
});

$(".imprCuaderno").click(function(){
			window.print();
})

}

document.querySelector(".cerrarSesion").addEventListener("click",()=>{

	cerrarSesion()
})

recibirData(data)
