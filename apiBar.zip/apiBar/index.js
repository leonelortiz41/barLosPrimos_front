const mysql=require('mysql');
const expres=require('express')
const _=require('underscore')
var bodyParser = require('body-parser')
const cors=require('cors')
const app=expres();
const PORT= process.env.PORT || 3000;
const milanesas=[],hamburguesas=[],lomitos=[],pizzas=[],papas=[],platos=[],empandas=[],bebidas=[];
let pedidos=[],pedidosPost;
app.use(cors())
var jsonParser = bodyParser.json()
var urlencodedParser = bodyParser.urlencoded({ extended: false })

const server=app.listen(PORT,function() {
	console.log(`funcionando en el puerto ${PORT}`)
});

//conect to database mysql
const conection= mysql.createConnection({
	host:'localhost',
	user:'root',
	password:'',
	database:'menu-bar-los-primos'
})

const conectar=()=>{
	conection.connect((err)=>{
		if(err) throw err;
		else
		console.log("la conexion a la base de datos es exitosa");
	});
}

//rauters

app.get('/pedidos',(req,res)=>{
	 extraerDatos(pedidos,"pedidos",res)
	
})
app.post('/pedidos',jsonParser,(req,res)=>{
	console.log(req.body)
	pedidosPost=req.body
	enviarData(pedidosPost)
	res.send(req.body)

})
app.delete("/pedidos/:id",(req,res)=>{
	const { id } = req.params;
	_.each(pedidos,(pedido,i)=>{
		if(pedido.id!=null && pedido.id==id){
			conection.query(`DELETE FROM pedidos WHERE pedidos.id = ${id}`)
			console.log(id)
			
		}
	}
	)
	res.json(req.body)
	console.log(req.body)
	pedidos=[]
})
app.put("/pedidos/:id",jsonParser,(req,res)=>{
	const { id } = req.params;
	// let {cantidad,cliente,detalle,importe,detalleTicket}=req.body
	pedidosPost=req.body
	console.log("se realizo metodo put y los nuevos datos son:");
	console.log(req.body)

			editarData(pedidosPost,id);

	res.send(req.body)
	// pedidos=[]
})
app.delete('/pedidos',(req,res)=>{
	pedidos=[];
	borrarDatos("pedidos")
})

//funciones
const extraerDatos=  async function(table,sql,res){
		conection.query(`SELECT * from ${sql}`, async (err, rows) => {
		if (err)
			throw err;


		else
			for (var i = 0; i < rows.length; i++) {
				table[i] = await rows[i];
			}
		res.json(pedidos)
	})
}
const borrarDatos= function(sql){
		conection.query(`TRUNCATE TABLE pedidos`)
		console.log("se borraron todos los registros")
}
const enviarData= function(pedidosPost){
		let cantidad=pedidosPost.cantidad;
		let detalle="";
		let detalleTicket=pedidosPost.detalle
		let cliente=pedidosPost.cliente
		let importe=pedidosPost.importe
		
		for (let i = 0; i < pedidosPost.pedido.length; i++) {
			let serializado=JSON.stringify(pedidosPost.pedido[i])
			if (detalle=="") 	detalle=serializado;
			else  detalle =detalle + `,` + serializado;			
		}		
		pedidosPost="";
		conection.query(`INSERT INTO pedidos (cantidad, cliente, detalle, importe, detalleTicket) VALUES ("${cantidad}","${cliente}", '${detalle}', "${importe}","${detalleTicket}")`,(err,rows)=>{
			if(err) throw err;
			else
			console.log("los nuevos datos se enviaron correctamente")
		})
		pedidos=[];
}

const editarData= function(pedidosPost,id){
	let cantidad=pedidosPost.cantidad;
	let detalle="";
	let detalleTicket=pedidosPost.detalle
	let cliente=pedidosPost.cliente
	let importe=pedidosPost.importe
	
	for (let i = 0; i < pedidosPost.pedido.length; i++) {
		let serializado=JSON.stringify(pedidosPost.pedido[i])
		if (detalle=="") 	detalle=serializado;
		else  detalle =detalle + `,` + serializado;			
	}		
	pedidosPost="";
	conection.query(`UPDATE pedidos SET cliente = '${cliente}', detalle = '${detalle}', importe = '${importe}', detalleTicket = '${detalleTicket}', cantidad = '${cantidad}' WHERE pedidos.id = ${id}`,(err,rows)=>{
		if(err) throw err;
		else
		console.log("los nuevos datos se actualizaron correctamente")
	})
	pedidos=[];
}

// conection.end();